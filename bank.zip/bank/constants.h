#define FILENAME "accounts.csv"
#define DEFAULT_LOAN_INTEREST 500 // 5%